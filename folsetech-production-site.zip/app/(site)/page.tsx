import Container from "@/components/container";
import Hero from "@/components/hero";
import ServiceGrid from "@/components/service-grid";
import PortfolioGrid from "@/components/portfolio-grid";
import SectionHeading from "@/components/section-heading";
import GlowCard from "@/components/glow-card";
import LocalBusinessSchema from "@/components/seo/LocalBusinessSchema";

export default function HomePage() {
  return (
    <div>
      <LocalBusinessSchema city="Gonzales" region="LA" postalCode="70737" />
      <Hero />

      <section className="py-16">
        <Container>
          <SectionHeading
            eyebrow="Services"
            title="High-performance websites + SEO + automation"
            subtitle="Modern Next.js builds with a clean, tech-forward design language—optimized for speed, accessibility, and local search."
          />
          <div className="mt-8">
            <ServiceGrid />
          </div>
        </Container>
      </section>

      <section className="py-16 border-t border-line">
        <Container>
          <SectionHeading
            eyebrow="Portfolio"
            title="Work that looks sharp and converts"
            subtitle="A few sample project-style showcases with motion and polish. Replace with real client work as you add it."
          />
          <div className="mt-8">
            <PortfolioGrid />
          </div>
        </Container>
      </section>

      <section className="py-16 border-t border-line">
        <Container>
          <SectionHeading
            eyebrow="Service Areas"
            title="Proudly Serving South Louisiana"
            subtitle="City landing pages built for local SEO and fast conversions."
          />
          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <a href="/locations/baton-rouge" className="rounded-xl border border-line p-4 hover:bg-white/5 transition">
              Baton Rouge Web Design
            </a>
            <a href="/locations/prairieville" className="rounded-xl border border-line p-4 hover:bg-white/5 transition">
              Prairieville Web Design
            </a>
            <a href="/locations/denham-springs" className="rounded-xl border border-line p-4 hover:bg-white/5 transition">
              Denham Springs Web Design
            </a>
          </div>
        </Container>
      </section>

      <section className="py-16 border-t border-line">
        <Container>
          <GlowCard className="shadow-gold">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div>
                <div className="text-xs tracking-[0.2em] uppercase text-gold/90">Ready to launch?</div>
                <h3 className="mt-2 text-xl md:text-2xl font-semibold">
                  Let’s build a fast, modern website for your business.
                </h3>
                <p className="mt-2 text-sm text-ink/70">Clean design. Smart SEO. Automation that saves time.</p>
              </div>
              <a href="/contact" className="inline-flex h-11 items-center justify-center rounded-xl bg-gold text-bg px-5 text-sm font-semibold shadow-gold hover:bg-gold/90">
                Let’s Build Together
              </a>
            </div>
          </GlowCard>
        </Container>
      </section>
    </div>
  );
}
